import { Comments } from "./Components/Comments";
import "./styles.css";
export default function App() {
  return (
    <div className="App">
      <Comments />
    </div>
  );
}
