import axios from "axios";
import { useEffect, useState } from "react";
import styles from "./Comments.module.css";
import { SingleComment } from "./SingleComment";
export const baseUrl = "http://localhost:8000";
export function Comments() {
  const [commentsData, setCommentsData] = useState([]);
  useEffect(() => {
    getData();
  }, []);
  async function getData() {
    try {
      let { data } = await axios.get(`${baseUrl}/comments`);
      setCommentsData(data);
    } catch (error) {
      console.log(error, "error");
    }
  }

  return (
    <div>
      {commentsData.map((item) => {
        return <SingleComment key={item.id} item={item} getData={getData} />;
      })}
    </div>
  );
}
