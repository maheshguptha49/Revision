import axios from "axios";
import { useState } from "react";
import { baseUrl } from "./Comments";
import styles from "./Comments.module.css";

export function SingleComment({ item, getData }) {
  const [repliesShow, setRepliesShow] = useState(false);
  const [repliesInputShow, setRepliesInputShow] = useState(false);
  const [formData, setFormData] = useState("");
  function openReplies() {
    setRepliesShow((item) => !item);
  }
  function openRepliesInput() {
    setRepliesInputShow((item) => !item);
  }
  async function handleSubmit() {
    try {
      const authors = ["akshay", "rushikesh", "mahesh", "deependra", "mahesh"];
      const comments = [
        "super",
        "nice",
        "wow man",
        "excellent bro",
        "cant express my words wow"
      ];
      let randomNumber = Math.floor(Math.random() * 4);
      const payload = {
        commentData: {
          id: item.id + 1,
          author: authors[randomNumber],
          body: formData
        },
        parentCommentId: item.id
      };
      await axios.post(`${baseUrl}/comments`, payload);
      getData();
    } catch (error) {
      console.log(error);
    }
  }
  return (
    <div key={item.id} className={styles.commentDiv}>
      <div>
        <button
          onClick={() => {
            openReplies();
          }}
        >
          +
        </button>
      </div>
      <div>
        <div>
          <span>{item.author}</span>
          <span>{item.points} points </span>
          <span>16 hours ago</span>
        </div>
        <div>
          <p>{item.body}</p>
        </div>
        <div>
          <div>
            <span className={styles.replyText} onClick={openRepliesInput}>
              Reply
            </span>
            <span>Report</span>
            <span>Save</span>
          </div>
          <div
            style={{
              display: repliesInputShow ? "block" : "none",
              marginTop: "10px"
            }}
          >
            <input type="text" onChange={(e) => setFormData(e.target.value)} />
            <button
              className={styles.reply}
              onClick={() => {
                handleSubmit();
              }}
            >
              reply{" "}
            </button>
          </div>
        </div>
        <div style={{ marginLeft: "20px" }}>
          {repliesShow &&
            item?.replies?.map((item) => {
              return (
                <SingleComment key={item.id} item={item} getData={getData} />
              );
            })}
        </div>
      </div>
    </div>
  );
}
